

     <html>
         <head>
             <title> Welcome</title>
             <meta charset="utf-8">
             <meta name="viewport" content="width=device-width, initial-scale=1">
              <link rel="stylesheet" href="/BookRentSystem/css/bootstrap.min.css">
             <style>
                 body
                 {
                     background-color: #a3dede;  
                 }
                 .wrapper{
                     
                     background-size:cover;
                 }
                 img{
                     width:1350px;
                 }
                 
             </style>
              
       </head>
       
        <body>
            <div class="nav navbar-inverse">
                <div class="container-fluid">
                    <ul class="nav navbar-nav">
                        <li><a href="Welcome.php">HOME</a></li>
                        <li><a href="">About Us</a></li>
                        
                    </ul>
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="SignUp.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
                        <li><a href="LoginPage.php"><span class="glyphicon glyphicon-log-in"></span> Log in</a></li>
                        
                    </ul>
                </div>
            </div>
         
                    <div class="wrapper">
                        <img src="clock.jpg"/>
                    </div>
                  
        </body>
     </html>



