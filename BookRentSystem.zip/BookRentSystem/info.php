<?php
      
       $name=array("DHRUV R","JAIMISH J","MAITRI","RONIT R","SAGAR B","SAGAR V","UNNATI","VIVEK J");
       $rn=array("091","092","093","095","096","097","098","099");
       $image=array(" "," "," "," "," "," "," ","CE099.png");
?>

     


