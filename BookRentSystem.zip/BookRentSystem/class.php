  <?php
					            class Cartobject
								{
								      public $c_bookid;
									  public $c_bookname;
									  public $c_bookprice;
									  public $c_bookrent;
									  public $c_renttime;
									  
									  
									  public function __construct($c_bookid,$c_bookname,$c_bookprice,$c_bookrent,$c_renttime)
									  {
									      $this->c_bookid=$c_bookid;
										  $this->c_bookname=$c_bookname;
										  $this->c_bookprice=$c_bookprice;
										  $this->c_bookrent=$c_bookrent;
										  $this->c_renttime=$c_renttime;
									      
									  }
									  
								     
								}
					   
					   
                         ?>					   
       